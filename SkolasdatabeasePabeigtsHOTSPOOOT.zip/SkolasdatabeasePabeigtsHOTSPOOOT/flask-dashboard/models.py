from peewee import *
from datetime import datetime

db = SqliteDatabase('app.db')

class BaseModel(Model):
    class Meta:
        database = db

class UploadLog(BaseModel):
    filename = CharField()
    upload_time = DateTimeField(default=datetime.now)

def initialize_db():
    if db.is_closed():
        db.connect()
    db.create_tables([UploadLog], safe=True)