
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import os
from models import initialize_db
import pandas as pd
import matplotlib

# Iestatīt matplotlib backend uz 'Agg' servera videi
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
from models import UploadLog

# Inicializēt Flask lietotni
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Nepieciešams flash ziņojumiem

# Konfigurēt augšupielādes direktorijas iestatījumus
UPLOAD_FOLDER = 'data'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Izveidot augšupielādes direktoriju, ja tā neeksistē
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    """Sākumlapas maršruts, kas attēlo jaunākās augšupielādes"""
    try:
        # Iegūt 10 jaunākās augšupielādes no datubāzes
        uploads = UploadLog.select().order_by(
            UploadLog.upload_time.desc()).limit(10)
    except Exception as e:
        uploads = []
        flash(f"Nevarēja iegūt augšupielāžu vēsturi: {e}")
    return render_template('home.html', uploads=uploads)

@app.route('/uploads')
def uploads():
    """Maršruts visu failu augšupielādes vēstures attēlošanai"""
    from models import UploadLog
    uploads = UploadLog.select().order_by(UploadLog.upload_time.desc())
    return render_template('uploads.html', uploads=uploads)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Apstrādāt failu augšupielādes un CSV validāciju"""
    if request.method == 'POST':
        file = request.files.get('csv_file')
        if file and file.filename.endswith('.csv'):
            # Nodrošināt faila nosaukumu un saglabāt failu
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Reģistrēt augšupielādi datubāzē
            UploadLog.create(filename=filename)
            
            # Nolasīt CSV un saglabāt kā pickle ātrākai piekļuvei
            df = pd.read_csv(filepath)
            df.to_pickle("data/last_upload.pkl")

            flash('CSV fails veiksmīgi augšupielādēts!')
            return redirect(url_for('dashboard'))
        else:
            flash('Lūdzu augšupielādējiet derīgu CSV failu.')
            return redirect(request.url)

    return render_template('upload.html')

@app.route('/dashboard')
def dashboard():
    """Galvenais info paneļa maršruts ar datu vizualizāciju"""
    try:
        # Ielādēt pēdējo augšupielādēto datu kopu
        df = pd.read_pickle("data/last_upload.pkl")

        # Identificēt kolonnu tipus dažādām vizualizācijām
        numeric_cols = df.select_dtypes(include='number').columns.tolist()
        categorical_cols = df.select_dtypes(exclude='number').columns.tolist()
        date_cols = [
            col for col in df.columns
            if 'date' in col.lower() or df[col].dtype == 'object'
        ]

        # Iegūt izvēlētās kolonnas no URL parametriem
        selected = request.args.get(
            "column", default=numeric_cols[0] if numeric_cols else None)
        selected_cat = request.args.get(
            "cat_col",
            default=categorical_cols[0] if categorical_cols else None)
        selected_date = request.args.get("date_col")
        selected_metric = request.args.get("metric_col")

        # Iegūt filtra vērtības histogrammai
        min_val = request.args.get("min_val", type=float)
        max_val = request.args.get("max_val", type=float)

        # Ģenerēt statistikas kopsavilkumu
        stats = df.describe().round(2).to_html(classes='table table-bordered')

        # Ģenerēt Matplotlib histogrammu
        plot_url = None
        filtered_series = df[selected] if selected in df.columns else None
        if filtered_series is not None:
           
            if min_val is not None:
                filtered_series = filtered_series[filtered_series >= min_val]
            if max_val is not None:
                filtered_series = filtered_series[filtered_series <= max_val]

            # savo histogrammu
            plt.figure(figsize=(8, 5))
            filtered_series.hist(bins=20)
            plt.title(f'Histogram of {selected}')
            plt.xlabel(selected)
            plt.ylabel('Frequency')
            plt.tight_layout()
            img = io.BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            plot_url = "data:image/png;base64," + base64.b64encode(
                img.read()).decode()
            plt.close()

        # izveido Plotly histogram
        import plotly.express as px
        plotly_hist_html = None
        if filtered_series is not None:
            try:
                fig = px.histogram(
                    filtered_series.to_frame(),
                    x=selected,
                    nbins=20,
                    title=f"Interactive Histogram of {selected}")
                fig.update_layout(bargap=0.1)
                plotly_hist_html = fig.to_html(full_html=False)
            except Exception as e:
                flash(f"Plotly error: {e}")

        # Izveido bar chart prieks data
        cat_plot_url = None
        if selected_cat and selected_cat in df.columns:
            value_counts = df[selected_cat].value_counts()
            plt.figure(figsize=(8, 5))
            value_counts.plot(kind='bar')
            plt.title(f'Bar Chart of {selected_cat}')
            plt.xlabel(selected_cat)
            plt.ylabel('Count')
            plt.tight_layout()
            img = io.BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            cat_plot_url = "data:image/png;base64," + base64.b64encode(
                img.read()).decode()
            plt.close()

        # izveido time series line chart
        line_plot_url = None
        if selected_date and selected_metric:
            try:
                # Konvertējiet datuma kolonnu
                df[selected_date] = pd.to_datetime(df[selected_date],
                                                   errors='coerce')
                df_grouped = df.groupby(
                    selected_date)[selected_metric].mean().dropna()
                plt.figure(figsize=(8, 5))
                df_grouped.plot(kind='line', marker='o')
                plt.title(f'{selected_metric} Over Time ({selected_date})')
                plt.xlabel(selected_date)
                plt.ylabel(f'Average {selected_metric}')
                plt.grid(True)
                plt.tight_layout()
                img = io.BytesIO()
                plt.savefig(img, format='png')
                img.seek(0)
                line_plot_url = "data:image/png;base64," + base64.b64encode(
                    img.read()).decode()
                plt.close()
            except Exception as e:
                flash(f"Line chart error: {e}")

        # rendero panela vizualizāciju 
        return render_template("dashboard.html",
                               columns=numeric_cols,
                               cat_columns=categorical_cols,
                               date_cols=date_cols,
                               stats=stats,
                               selected=selected,
                               selected_cat=selected_cat,
                               selected_date=selected_date,
                               selected_metric=selected_metric,
                               min_val=min_val,
                               max_val=max_val,
                               plot_url=plot_url,
                               plotly_hist_html=plotly_hist_html,
                               cat_plot_url=cat_plot_url,
                               line_plot_url=line_plot_url)
    except Exception as e:
        flash(f"Error loading dashboard: {e}")
        return redirect(url_for('upload'))

if __name__ == '__main__':
    # Inicializēt datubāzi un palaist Flask izstrādes serveri
    initialize_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
